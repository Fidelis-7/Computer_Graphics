import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;

public class Objects extends JComponent {

    @Override
    public void paint(Graphics g){
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        //methods to print objects
        house(g2d);
    }

    public void house(Graphics2D g2d){
        AffineTransform resetTrans = g2d.getTransform();
        g2d.scale(1.5, 1.5);
        g2d.translate(50, 50);

        //small side building
        //roof
        g2d.setColor(Color.decode("#4D4640"));
        int[] xpoints11 = {307, 307, 447, 448};
        int[] yPoints11 = {224, 109, 122, 235};
        g2d.fillPolygon(xpoints11, yPoints11, xpoints11.length);
        //main building
        g2d.setColor(Color.decode("#B94826"));
        int[] xpoints13 = {295, 295, 437, 437};
        int[] yPoints13 = {307, 231, 237, 307};
        g2d.fillPolygon(xpoints13, yPoints13, xpoints13.length);
        //roof gutter
        g2d.setColor(Color.decode("#FBD0C7"));
        int[] xpoints12 = {307, 307, 447, 447};
        int[] yPoints12 = {231, 223, 235, 244};
        g2d.fillPolygon(xpoints12, yPoints12, xpoints12.length);
        //draw garage door
        g2d.setColor(Color.decode("#4C4741"));
        int[] xpoints14 = {312, 312, 419, 419};
        int[] yPoints14 = {307, 256, 256, 307};
        g2d.fillPolygon(xpoints14, yPoints14, xpoints14.length);
        g2d.setStroke(new BasicStroke(3f));
        g2d.setColor(Color.decode("#3C352F"));
        g2d.drawLine(318, 264, 412, 264);
        g2d.translate(0, 7);
        g2d.drawLine(318, 264, 412, 264);
        g2d.drawLine(318, 264, 412, 264);
        g2d.translate(0, 7);
        g2d.drawLine(318, 264, 412, 264);
        g2d.drawLine(318, 264, 412, 264);
        g2d.translate(0, 7);
        g2d.drawLine(318, 264, 412, 264);
        g2d.drawLine(318, 264, 412, 264);
        g2d.translate(0, 7);
        g2d.drawLine(318, 264, 412, 264);
        g2d.drawLine(318, 264, 412, 264);
        g2d.translate(0, 7);
        g2d.drawLine(318, 264, 412, 264);

        //reset scale then set scale
        g2d.setTransform(resetTrans);
        g2d.scale(1.5, 1.5);
        g2d.translate(50, 50);
        //shadow on small building
        g2d.setColor(new Color(0, 0, 0, 50));
        int[] xpoints15 = {294, 295, 437, 437, 328, 329, 339, 339};
        int[] yPoints15 = {307, 230, 244, 256, 244, 255, 255, 307}; //307 = foot of building
        g2d.fillPolygon(xpoints15, yPoints15, xpoints15.length);


        //Draw main building
        //draw main roof
        g2d.setColor(Color.decode("#332E2A"));
        int[] xPoints = {77, 77, 183, 202, 307, 307, 202, 182};
        int[] yPoints = {242, 108, 2, 2, 107, 242, 135, 135};
        g2d.fillPolygon(xPoints, yPoints, xPoints.length);
        g2d.drawPolygon(xPoints, yPoints, xPoints.length);

        //draw roof gutter
        g2d.setColor(Color.decode("#F2CFBB"));
        int[] xPoints2 = {75, 75, 182, 203, 308, 309, 201, 182};
        int[] yPoints2 = {253, 241, 136, 136, 242, 255, 149, 150};
        g2d.fillPolygon(xPoints2, yPoints2, xPoints2.length);


        //draw front main buildung front
        g2d.setColor(Color.decode("#D75426"));
        int[] xPoints4 = {89, 182, 200, 295, 295, 89};
        int[]yPoints4 = {240, 149, 148, 240, 336, 336};
        g2d.fillPolygon(xPoints4, yPoints4, xPoints4.length);

        //draw the shadow under roof for main building
        g2d.setColor(new Color(0, 0, 0, 50));
        int[] xPoints3 = {89, 89, 182, 201, 295, 295, 201, 182};
        int[] yPoints3 = {252, 241, 148, 149, 239, 252, 160, 160};
        g2d.fillPolygon(xPoints3, yPoints3, xPoints3.length);

        //small porch/door pillars
        //small roof
        g2d.setColor(Color.decode("#332E2A"));
        int[] xPoints5 = {147, 147, 236, 236};
        int[] yPoints5 = {270, 235, 236, 270};
        g2d.fillPolygon(xPoints5, yPoints5, xPoints5.length);
        //door
        g2d.setColor(Color.decode("#803317"));
        int[] xpoints7 = {169, 215, 215, 169};
        int[] yPoints7 = {277, 277, 328, 328};
        g2d.fillPolygon(xpoints7, yPoints7, xpoints7.length);
        //foor in front of door
        g2d.setColor(Color.decode("#A14921"));
        int[] xpoints8 = {148, 236, 236, 148};
        int[] yPoints8 = {327, 327, 364, 364};
        g2d.fillPolygon(xpoints8, yPoints8, xpoints8.length);
        g2d.setColor(Color.decode("#C76629"));
        int[] xpoints9 = {148, 236, 236, 148};
        int[] yPoints9 = {364, 364, 369, 369};
        g2d.fillPolygon(xpoints9, yPoints9, xpoints9.length);
        //pillars
        g2d.setColor(Color.decode("#FCF2E8"));
        g2d.fillRoundRect(152, 275, 8, 85, 10, 2);
        g2d.translate(70, 0);
        g2d.fillRoundRect(152, 275, 8, 85, 10, 2);

        //reset transformations and reintroduce scaling
        g2d.setTransform(resetTrans);
        g2d.scale(1.5, 1.5);
        g2d.translate(50, 50);

        //small gutter
        g2d.setColor(Color.decode("#FEFDFB"));
        int[] xpoints6 = {147, 237, 237, 147};
        int[] yPoints6 = {270, 270, 277, 277};
        g2d.fillPolygon(xpoints6, yPoints6, xpoints6.length);

        //shadow on atop main roof
        g2d.setColor(Color.decode("#4D4640"));
        int[] xpoints10 = {183, 202, 203, 182};
        int[] yPoints10 = {2, 2, 136, 135};
        g2d.fillPolygon(xpoints10, yPoints10, xpoints10.length);


        //chimney
        g2d.setColor(Color.decode("#D75426"));
        int[] xpoints19 = {238, 280, 281, 238};
        int[] yPoints19 = {108, 149, 88, 88};
        g2d.fillPolygon(xpoints19, yPoints19, xpoints19.length);

        g2d.setColor(Color.decode("#ED6A24"));
        int[] xpoints20 = {236, 236, 285,285};
        int[] yPoints20 = {88, 77, 77, 88};
        g2d.fillPolygon(xpoints20, yPoints20, xpoints20.length);

        g2d.setColor(Color.decode("#F49158"));
        int[] xpoints21 = {236, 284,284, 236};
        int[] yPoints21 = { 77, 77, 44, 44};
        g2d.fillPolygon(xpoints21, yPoints21, xpoints21.length);

        g2d.setColor(Color.decode("#86351A"));
        int[] xpoints22 = {244, 244,276, 275};
        int[] yPoints22 = {70, 52, 52, 70};
        g2d.fillPolygon(xpoints22, yPoints22, xpoints22.length);



        //windows
        g2d.setColor(Color.WHITE);
        g2d.fillRect(100, 250, 36, 56);
        g2d.fillRect(97, 305, 42, 6);
        g2d.setColor(Color.decode("#551D10"));
        g2d.fillRect(103,252, 30, 52);

        g2d.setColor(Color.WHITE);
        g2d.setStroke(new BasicStroke(2.5f));
        g2d.drawLine(104, 269, 134, 269);
        g2d.drawLine(104, 289, 134, 289);
        g2d.drawLine(119, 252, 119, 306);

        g2d.translate(145, 0);
        g2d.setColor(Color.WHITE);
        g2d.fillRect(100, 250, 36, 56);
        g2d.fillRect(97, 305, 42, 6);
        g2d.setColor(Color.decode("#551D10"));
        g2d.fillRect(103,252, 30, 52);

        g2d.setColor(Color.WHITE);
        g2d.setStroke(new BasicStroke(2.5f));
        g2d.drawLine(104, 269, 134, 269);
        g2d.drawLine(104, 289, 134, 289);
        g2d.drawLine(119, 252, 119, 306);

        g2d.translate(-70, -80);
        g2d.setColor(Color.WHITE);
        g2d.fillRect(100, 250, 36, 56);
        g2d.fillRect(97, 305, 42, 6);
        g2d.setColor(Color.decode("#551D10"));
        g2d.fillRect(103,252, 30, 52);

        g2d.setColor(Color.WHITE);
        g2d.setStroke(new BasicStroke(2.5f));
        g2d.drawLine(104, 269, 134, 269);
        g2d.drawLine(104, 289, 134, 289);
        g2d.drawLine(119, 252, 119, 306);



        //reset transformations
        g2d.setTransform(resetTrans);
        g2d.scale(1.5, 1.5);
        g2d.translate(50, 50);
    }
}
