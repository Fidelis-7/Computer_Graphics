

public class Main {

    public static void main(String[] args) {
        Canvas frame = new Canvas();
        Objects objects = new Objects();
        frame.add(objects);
    }
}