import javax.swing.*;
import java.awt.*;

public class Canvas extends JFrame {
    public int width = 920;
    public int height = 800;
    Objects jFrameSize = new Objects();

    public Canvas() {
        this.pack();
        this.setSize(width, height);
        this.getContentPane().setBackground(Color.WHITE);
        this.setTitle("Computer Graphics Final Project Work for 220031975");
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
}